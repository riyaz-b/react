import React from "react";

function Work() {
  return (
    <div>
      <h2>Welcome to the NTT Page</h2>
      <p>Plot No. 7, Embassy Oxygen Business Park, Tower F, Sector 144, Noida, Uttar Pradesh 201307
      NTT DATA Services, address.</p>
    </div>
  );
}

export default Work;