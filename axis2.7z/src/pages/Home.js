import React from "react";

function Home() {
  return (
    <div>
      <h2>Welcome to the Home Page</h2>
      <p>This is a simple React multi-page application.</p>
    </div>
  );
}

export default Home;