import React from "react";

function About() {
  return (
    <div>
      <h2>About Us</h2>
      <p>This page tells you more about our app.</p>
    </div>
  );
}

export default About;